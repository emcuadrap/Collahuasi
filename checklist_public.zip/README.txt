Checklist Vehicular Diario — Build estático
=============================================

Archivos:
- index.html  → sube este archivo a Netlify / Vercel (Static), GitHub Pages o cualquier hosting estático.

Cómo publicar rápido (Netlify Drop):
1) Entra a https://app.netlify.com/drop
2) Arrastra y suelta este index.html
3) Obtendrás una URL pública, por ejemplo: https://<tu-sitio>.netlify.app

Cómo conectar el Excel (SharePoint) sin tocar código:
- En Power Automate crea un trigger "When an HTTP request is received" → acción "Add a row into a table" → "Response 200" con { "ok": true } + cabecera CORS Access-Control-Allow-Origin: *
- Copia la URL del trigger (FLOW_ENDPOINT)
- Abre la URL pública de tu sitio agregando ?flow=<TU_FLOW_ENDPOINT>
  Ejemplo:
  https://<tu-sitio>.netlify.app/?flow=https%3A%2F%2Fprod-%2E%2E%2E%2Finvoke

Modo móvil (kiosco) para conductores:
- Usa el enlace con ?kiosk=1 para que solo se muestre el formulario
  Ejemplo:
  https://<tu-sitio>.netlify.app/?kiosk=1
  (Puedes combinarlo con flow: https://<tu-sitio>.netlify.app/?kiosk=1&flow=... )

Acceso a la base:
- En la sección "Códigos QR" dentro de la app puedes pegar el link del Excel/SharePoint para facilitar el acceso de administración.
